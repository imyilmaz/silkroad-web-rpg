// app/api/character/select/route.ts
import { NextResponse } from 'next/server'
import { getUserFromToken } from '@/lib/auth'
import prisma from '@/lib/prisma'

export async function POST(req: Request) {
  const user = await getUserFromToken()
  if (!user) return NextResponse.json({ message: 'Yetkisiz erişim' }, { status: 401 })

  const { id } = await req.json()

  const character = await prisma.character.findFirst({
    where: {
      id,
      userId: user.id,
    },
  })

  if (!character) return NextResponse.json({ message: 'Karakter bulunamadı.' }, { status: 404 })

  // Oturumu güncelle
  await prisma.session.upsert({
    where: { userId: user.id }, 
    update: { characterId: character.id },
    create: { userId: user.id, characterId: character.id },
  })

  return NextResponse.json({ message: 'Karakter seçildi.' })
}
