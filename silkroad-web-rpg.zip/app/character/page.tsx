'use client'

import React, { useEffect, useState } from 'react'

type Character = {
    id: number
    name: string
    race: string
    level: number
    exp: number
}

const CharacterPage = () => {
    const [characters, setCharacters] = useState<Character[]>([])
    const [selectedId, setSelectedId] = useState<number | null>(null)

    useEffect(() => {
        fetchCharacters()
    }, [])

    const fetchCharacters = async () => {
        const res = await fetch('/api/character/list')
        const data = await res.json()

        setCharacters(data.characters)
        setSelectedId(data.activeCharacterId)

        // Eğer daha önce seçim yapılmamışsa, ilk karakteri seç
        if (!data.activeCharacterId && data.characters.length > 0) {
            const firstChar = data.characters[0]
            await fetch('/api/character/select', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: firstChar.id }),
            })
            setSelectedId(firstChar.id)
        }
    }

    const handleSelect = async (id: number) => {
        const res = await fetch('/api/character/select', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id }),
        })
        if (res.ok) {
            setSelectedId(id)
        }
    }

    useEffect(() => {
        fetchCharacters()
    }, [])

    return (
        <div className="character-page">
            <h2>Karakterlerin</h2>
            <button
                onClick={() => window.location.href = '/home'}
                style={{
                    margin: '40px auto',
                    padding: '12px 24px',
                    fontSize: '16px',
                    borderRadius: '8px',
                    backgroundColor: '#8c37d1ff',
                    color: '#fff',
                    border: 'none',
                    cursor: 'pointer'
                }}
            >
                Şehire Dön
            </button>

            {characters.length === 0 && <p>Hiç karakterin yok.</p>}

            {selectedId && (
                <div className="active-character">
                    <h3>Aktif Karakter</h3>
                    {characters
                        .filter((char) => char.id === selectedId)
                        .map((char) => (
                            <div key={char.id}>
                                <p><strong>İsim:</strong> {char.name}</p>
                                <p><strong>Irk:</strong> {char.race}</p>
                                <p><strong>Seviye:</strong> {char.level}</p>
                                <p><strong>XP:</strong> {char.exp}</p>
                            </div>
                        ))}
                </div>
            )}

            <div className="character-list">
                {characters
                    .filter((char) => char.id !== selectedId)
                    .map((char) => (
                        <div key={char.id} className="character-card">
                            <div className="info">
                                <p>{char.name} ({char.race})</p>
                                <p>Lv: {char.level}</p>
                            </div>
                            <button
                                className="select-btn"
                                onClick={() => handleSelect(char.id)}
                            >
                                Seç
                            </button>
                        </div>
                    ))}
            </div>
        </div>
    )
}

export default CharacterPage
