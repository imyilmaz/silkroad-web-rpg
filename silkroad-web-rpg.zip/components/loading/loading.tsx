'use client'
import './Loading.scss'

const Loading = () => (
  <div className="loading-overlay">
    <div className="spinner" />
  </div>
)

export default Loading
